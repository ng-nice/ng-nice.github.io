import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-hero-list></app-hero-list>
    <app-sales-tax></app-sales-tax>
  `
})
export class AppComponent { }
