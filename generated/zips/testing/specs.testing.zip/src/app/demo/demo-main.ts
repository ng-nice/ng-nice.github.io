// main app entry point
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { DemoModule } from './demo';

platformBrowserDynamic().bootstrapModule(DemoModule);
